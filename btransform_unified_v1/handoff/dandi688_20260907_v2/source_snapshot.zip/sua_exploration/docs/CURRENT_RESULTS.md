# Current results: analytic functional carriers for streaming neural decoding

**Updated:** 2026-08-15 HKT
**Status:** concise terminal result ledger plus separate dated development rounds. Historical terminal results
remain authoritative; the B0 external bridge is a terminal system-comparator result, while A1 is a terminal
routing pilot and B1 stopped at terminal Stage P, with neither promoted to a confirmatory or formal result.
**Full project interpretation:**
[`HANDOFF_MAINLINE_CLOSURE_20260811.md`](HANDOFF_MAINLINE_CLOSURE_20260811.md)

This file contains result-level facts, scope, and evidence pointers. It replaces the former chronological
PID/tmux/epoch/launch diary. Historical implementation incidents remain recoverable from Git history, immutable
receipts, and the dated protocol documents still referenced by scripts and tests.

## 1. Result summary

| dataset / endpoint | principal R² result | evidence status |
|---|---:|---|
| external subject-M SUA | T4/Zero4/TS4 `0.356828/−0.057766/−0.115319`; T4−Zero4 `+0.414594` | terminal 270-cell matrix; 3/3 seed means and 15/15 session means positive |
| matched subject-shift interaction (A2 v2) | within T4/Z4 `0.574976/0.326008`; external sub-M `0.341367/−0.143399`; interaction `+0.235799` | terminal 3-seed matched-checkpoint interaction; bootstrap `[+0.100852,+0.371768]`; formal sub-C test sessions sealed |
| original-SPINT B0 subject shift | within sub-C `0.236417`; external sub-M `−0.116184`; external−within `−0.352600`; external T4−B0 `+0.457551` | terminal CPU score-only bridge, 3/3 external seed means negative; matched-streaming original-SPINT topology system comparator, not a published-SPINT checkpoint or carrier-causal contrast |
| external subject-M pseudo-MUA | T4/Zero4/TS4 `0.306073/−0.086878/−0.164314`; T4−Zero4 `+0.392951` | terminal controlled signal-view bridge |
| native M2 matched seed42 | SPINT/T4 `0.293110/0.382906`; delta `+0.089796` | 14/14 development cells; 7/7 session deltas positive; not the missing fresh three-seed gate |
| RT dense carrier | Full/B2 `0.441950/0.145148`; delta `+0.296802` | terminal 15-fold development matrix |
| RT sparse endpoint T4d | T4d/Zero4/B2 `0.448176/0.179272/0.145148`; deltas `+0.268905/+0.303028` | terminal 45-cell matrix, independent verifier PASS, exact-query B2 companion PASS; both sparse-mainline contrasts 15/15 positive |
| H1 sparse boundary | date1 H-SE5−Zero5 `+0.028469` (2/2 positive); date2 `−0.022590` (2/3 positive) | four-trial endpoint-only carrier does not replicate across dates; not an H1 main claim |
| H1 compact CarrierID | five-date H-C−H-S `+0.056287`; organizer-held `0.274939` vs paper-LR `0.261492` | separate dense-carrier compact-consumer and organizer-hidden evidence |
| H1 SPINT NeuronID capacity | W32 vs H-S-1024 four-date mean `+0.036381`; 4/4 meet `delta R² >= -0.03`; date-bootstrap `[+0.012598,+0.056262]` | activity-only SPINT topology retains performance with `99.22x` fewer identity parameters and `94.05x` fewer identity MACs; development seed-42 capacity result |
| M1 | Original/T4/D4 `0.648591/0.644766/0.643993`; matched carrier content `−0.00652` | carrier-content negative boundary |

## 2. Selected method and evidence boundary

The selected carrier is a fixed-width analytic session descriptor. For the canonical direction-tuning case,

```text
T4_i = [a_i, c_i, m_i, b_i]
m_i = sqrt(a_i^2 + c_i^2)
rate_i(theta) ~= b_i + a_i cos(theta) + c_i sin(theta)
```

Target-session calibration is closed form. It does not create an optimizer, execute backward, or update the
decoder. B3/B3T supplies temporal activity; T4 supplies cached functional identity. Offline source training and
query scoring still use dense behavior targets, so no-backpropagation and sparse-label claims apply only to
target-session calibration.

Evidence labels used below:

- **terminal:** complete frozen matrix plus terminal aggregate and required integrity checks;
- **organizer-held system result:** official aggregate without matched per-session attribution;
- **development:** complete local matrix on held-out development sessions;
- **nonterminal:** partial matrix, constructibility audit, or diagnostic; never a paper headline.

## 3. External subject-M SUA and pseudo-MUA

### 3.1 Terminal V9 three-arm matrix

The matrix contains 15 sessions × 2 views × 3 separately source-trained arms × 3 seeds = 270 cells. Activity
uses the first 30 rewarded trials, carrier fitting uses the first 50 trial-direction labels, and query windows are
strictly after trial 50. Target-session optimizer/backward/weight update counts are zero.

| view | T4 | Zero4 | TS4 | T4−Zero4 | T4−TS4 |
|---|---:|---:|---:|---:|---:|
| SUA | `0.356828` | `−0.057766` | `−0.115319` | **`+0.414594`** | **`+0.472147`** |
| pseudo-MUA | `0.306073` | `−0.086878` | `−0.164314` | **`+0.392951`** | **`+0.470387`** |

All four contrasts are positive for 3/3 seed means and 15/15 session means; exact sign p for each is
`6.1035e-5`. Hierarchical-bootstrap 95% intervals are:

- SUA T4−Zero4 `[0.340273,0.488060]`;
- SUA T4−TS4 `[0.395148,0.549113]`;
- pseudo-MUA T4−Zero4 `[0.314165,0.472539]`;
- pseudo-MUA T4−TS4 `[0.388574,0.553836]`.

The pseudo-MUA view is a deterministic electrode-level sum of the same sorted SUA data. It demonstrates robustness
to the signal representation, not an independent native threshold-crossing replication.

### 3.2 Label budget

The activity support remains fixed at 30 trials and the evaluation window remains after trial 50.

| T4 labels | pooled fraction | SUA R² | Δ vs M50 | pseudo-MUA R² | Δ vs M50 |
|---:|---:|---:|---:|---:|---:|
| 10 | `3.49%` | `0.304264` | `−0.052565` | `0.259185` | `−0.046888` |
| 15 | `5.24%` | `0.338115` | `−0.018713` | `0.288234` | `−0.017839` |
| 20 | `6.98%` | `0.351767` | `−0.005061` | `0.298447` | `−0.007626` |
| 30 | `10.47%` | `0.358154` | `+0.001326` | `0.305291` | `−0.000782` |
| 40 | `13.96%` | `0.351648` | `−0.005180` | `0.301075` | `−0.004997` |
| 50 | `17.45%` | `0.356828` | `0` | `0.306073` | `0` |

M15 passes the frozen point-estimate and three-seed `−0.03` adequacy gate but not a CI-based non-inferiority
claim. M30 is the stronger deployment point: the SUA/pseudo intervals `[-0.00978,+0.01257]` and
`[-0.01288,+0.00966]` lie within the `−0.03` margin. A separate true-early-start replay verifies positive decoding
immediately after trial 30 rather than only after trial 50.

### 3.3 Classical comparators and supervision density

| view | historical F0-B3 | PV50 | T4 | Ridge50 |
|---|---:|---:|---:|---:|
| SUA | `−0.196077` | `0.115374` | `0.356828` | **`0.417922`** |
| pseudo-MUA | `−0.204725` | `0.104219` | `0.306073` | **`0.410193`** |

T4 exceeds PV50 by `+0.241454/+0.201854` but is below Ridge50 by `−0.061094/−0.104120`. Do not claim that
T4 beats dense-label ridge. Across the 15 sessions, T4 uses 750 direction scalars; the evaluated Ridge50 uses
149,725 finite 2-D target rows or 299,450 scalar coordinates. The ratios are `199.633x` by rows and `399.267x`
by coordinates. They measure algorithmic target-supervision consumption, not independent samples, manual effort,
compute, latency, memory, or energy.

The corrected CPU-only Priority-A2 program is terminal. A2a-v2 shows that the dense-velocity versus trial-direction
gap persists after solver normalization and row-weighting correction (`+0.46` to `+0.56` across the tested grid),
but this remains a target-content/granularity comparison rather than a pure density contrast. A2b-v2 then fixes the
dense velocity target, `50*N` representation, normalized `lambda=1` ridge, equal-trial weighting, and query set,
varying only the target-blind number of labelled windows per trial. Its predeclared `K=all−K=1` contrast is positive
in 14/15 sessions at M30/M50 in both views: SUA `+0.289/+0.328` and pseudo-MUA `+0.297/+0.312`, with bootstrap
intervals excluding zero. M15 remains uncertain because its intervals include zero.

Intermediate `K=8/16` grand means are heavy-tailed and mask-sensitive: one exceptional session drives the negative
aggregates while the other 14 session means are positive. The receipts do not record condition diagnostics, so do
not call this numerical ill-conditioning or a population-wide reversal. A2 identifies a within-ridge label-density
effect; it does not turn T4 versus Ridge50 into an information-, architecture-, or compute-matched causal comparison.
See `HANDOFF_TRIAL_LEVEL_RIDGE.md` and `DELIVERABLE_A2_WEIGHTING_AND_DENSITY.md`.

Evidence:

- V9 terminal aggregate under `results/dandi_000688_subm_v9_*`;
- label-budget aggregate SHA `12c4aead244631ed55e5a3eae7f99c87c4cfc4131ac37aa1f84aa55e5e0d4cc2`;
- true-early-start aggregate SHA `2e858403ae01da06c15448b6c3f8685f88eee9a9dc7a9da63acda332b926b12b`;
- F0/PV/Ridge aggregate SHA `ffccd91fc128edb7ad6199671f2e32d0c6c450cdff4f2b3d734a1815b176ebc0`;
- supervision audit SHA `43582628a86e80d08d91c60ce3f283502076bac951b06499649042e61feeea03`.
- valid A2a-v2 receipt SHA `b6a080c48d36adc74050f0a6672623585320e32bada45001a962622379bcba58`;
- valid A2b-v2 receipt SHA `0d4cd01b5fea86e2dca4640731f99faa2abde57d3d163bf7dee6ac34ed167361`.

### 3.4 Matched target-subject-shift interaction

A2 v2 trains one T4 and one matched Z4 source checkpoint per seed, then scores the unchanged epoch-5--12
checkpoint bundle on both the six-session sub-C development domain and the 15-session external sub-M domain.
The target-session first-30 direction-label carrier fit is disclosed; target velocity-label weight updates,
backward gradients, decoder updates, and target normalizer refitting are all absent.

| domain | Z4 | T4 | T4−Z4 |
|---|---:|---:|---:|
| within sub-C development | `0.326008` | `0.574976` | `+0.248968` |
| external sub-M | `−0.143399` | `0.341367` | `+0.484766` |

The external-minus-within interaction in `T4-Z4` is `+0.235799`; seed interactions are
`+0.230085/+0.187631/+0.289681`, and the crossed seed-by-session bootstrap interval is
`[+0.100852,+0.371768]`.  All frozen primary and secondary gates pass.  This supports increased **relative
carrier value** under the observed C-to-M subject shift.  It is not an absolute T4 lift of `+0.235799`, not a
biological unit-correspondence test, and not directly interchangeable with the M50 external matrix above.
The negative external Z4 mean also includes the strict source-C behavior-normalizer transfer condition and
must not be interpreted in isolation.  The six formal sub-C test sessions remained sealed.

Authoritative immutable aggregate:
`results/a2_matched_subject_shift_v2/terminal_aggregate.json`, SHA-256
`5b1459df7f65b8dd4cf4ebb9e29b7f82a6def6fc538af71bd822ee26fc7305fc`.

### 3.5 Original-SPINT B0 external bridge

The CPU-only bridge evaluates the archived original-SPINT identity topology under the matched streaming source
protocol on the same 15 external subject-M sessions and fixed logical epochs 5--12 used by the A2 comparison.
B0 uses the trainable copied `fc_id_in`/`fc_id_out` identity path with `side_dim=0`; it receives no target
direction carrier.  No new training, target-session optimizer/backward/update, GPU execution, or formal sub-C
test access occurred.

| quantity | mean R² | seed 42 / 43 / 44 |
|---|---:|---:|
| B0 within sub-C (A11 authority) | `+0.236417` | `+0.287760 / +0.179848 / +0.241641` |
| B0 external sub-M | **`−0.116184`** | `−0.118807 / −0.096352 / −0.133392` |
| B0 external minus within | **`−0.352600`** | `−0.406567 / −0.276200 / −0.375033` |
| external T4 minus B0 | **`+0.457551`** | `+0.421876 / +0.453572 / +0.497205` |
| external Z4 minus B0 | `−0.027215` | `−0.055379 / +0.006965 / −0.033233` |

B0 is positive within subject but negative on every external seed.  This supports the narrow interpretation that
the large activity-derived original-SPINT identity path learns useful within-domain structure that does not
survive this C-to-M subject shift.  Its external score is close to A2 Z4 (`−0.143399`), while T4 remains
positive (`+0.341367`); the result therefore strengthens the use of Z4 as a deployment-failure proxy and the
claim that a task-frame carrier supplies transferable identity.  The clean carrier-content evidence remains
the matched A2 T4-versus-Z4 interaction.  T4-versus-B0 and Z4-versus-B0 are system contrasts that also change
encoder topology and training lineage, so they are not pure carrier causal effects and are not claims about a
published SPINT checkpoint.

Authoritative immutable aggregate:
`results/subm_b0_external_score_bridge_v1/terminal_aggregate.json`, SHA-256
`913e58ec8556aff61fb25fe8571a94102136652f467cb190f5a0c14c3cec6211`.

## 4. Native M2

### 4.1 Matched Stage-A development result

| arm | seven-session equal-fold mean R² |
|---|---:|
| matched SPINT | `0.293110` |
| matched-decoder T4 | **`0.382906`** |
| T4−SPINT | **`+0.089796`** |

Seven session deltas are
`+0.115231/+0.059998/+0.187562/+0.029894/+0.068974/+0.016567/+0.150345`.
This is exact 14/14 seed42 development evidence. It cannot be combined with separately trained seeds43/44 to
invent the missing fresh r10 three-seed lineage.

The organizer-held T4 system exceeds the original system by `+0.116765`, but the comparator is not a matched
retraining; treat this as system-level evidence only.

### 4.2 M24 ridge diagnostic

On the strict local M24/q24 six-session endpoint:

| system | mean R² |
|---|---:|
| fixed-lambda Ridge24-W50 | `0.113916` |
| legacy F0 | `0.173901` |
| T4 | `0.226786` |
| K4 | `0.245774` |

T4−Ridge is `+0.112870`; K4−T4 is only `+0.018987`, below the frozen `+0.03` gate. Ridge24 is a per-session
closed-form fit without backpropagation. It is one fixed implementation, not a ridge-family upper bound.

## 5. RT

### 5.1 Dense carrier versus SPINT-structured reference: terminal

| arm | mean R² |
|---|---:|
| Full dense-velocity carrier | **`0.4419498241`** |
| B2-D1024 | `0.1451479751` |
| paired Full−B2 | **`+0.2968018490`** |

All 15 folds are positive; median `+0.3168286171`, exact sign p `0.00006103515625`, and paired-fold bootstrap
95% interval `[+0.2377831355,+0.3524398339]`. B2 is a same-pipeline SPINT-structured identity reference, not a
claim of a bit-exact released-code RT port.

Terminal aggregate:
`results/k4_rt_loso_v1/RT_STAGE_R_D1024_FULL15_AGGREGATE_v1.json`, SHA
`95bca578cd9ac412c88eb29b96e22c3eda5968ecb39b8f21dfc8c3fff5b536b8`.

### 5.2 Sparse endpoint carrier: terminal

RT has no non-degenerate native per-reach target field. The production method derives one direction per reach from
go-cue-bounded endpoint coordinates. Therefore it can support an algorithmic supervision-density claim, but not a
native annotation-cost claim.

Constructibility evidence:

- endpoint coverage min/median `0.964286/1.0`;
- 60--88 derived reach angles per session;
- rank-3 designs with condition `1.437--1.603`;
- endpoint versus dense-integrated direction cosine `0.999991--0.999997`;
- split-half `[a,c]` cosine median `0.787119`;
- correct-minus-shuffle forward-transfer mean/median `+0.035910/+0.031461`, 15/15 sessions positive.

The estimator consumes 1,103 reach-direction scalars versus 7,855 dense 2-D velocity rows / 15,710 scalar
coordinates: `7.121x/14.243x`. The interpolation implementation actually reads 5,502 coordinate scalars, so its raw
coordinate-I/O ratio is `2.855x`.

The terminal 15-fold Stage-2 matrix reports:

| arm / contrast | result |
|---|---:|
| T4d mean | `0.448176` |
| Zero4 mean | `0.179272` |
| matched SPINT-structured B2-D1024 mean | `0.145148` |
| T4d−Zero4 mean / median / drop-largest | **`+0.268905/+0.241568/+0.259142`** |
| T4d−Zero4 signs | **15/15 positive**; exact sign-test `p=6.1035e-5` |
| T4d−B2 mean / median / drop-largest | **`+0.303028/+0.292102/+0.291237`** |
| T4d−B2 signs | **15/15 positive**; exact sign-test `p=6.1035e-5` |
| prospective folds4--14 T4d−B2 | **`+0.311178` mean, `+0.304175` median, 11/11 positive; gate PASS** |

All 45 fresh cells closed and the read-only independent verifier passed. The B2 companion then evaluated all 15
sealed checkpoints forward-only on the exact Stage-2 query identities without retraining, reselection, optimizer,
backward, or state mutation. Endpoint-derived T4d strongly beats both Zero4 and the same-pipeline SPINT-structured
B2-D1024 reference. As a separate dense-supervision context only, dense Full has mean `0.445189` versus T4d
`0.448176`, an average difference of `+0.002987`; no superiority, equivalence, or non-inferiority claim is made.

Key receipt SHAs:

- Stage0B constructibility `b88c91ab5cfb30b4a9ef978622e00488193c4ad18b09498c84ba76e10b9943b1`;
- supervision closure `b826aa49e1d045da22068f5a9c12e2672d700d073549134105029051327b5f16`;
- Stage1 `9b69eaaa2339610116a5db8efa23ba20ad61459373293d98e80ceec294c3d0e9`;
- Stage2 readiness `183ae60c314d1213d0c5429545d54f5c34d71a8a170df52c381480de157ba87d`;
- matrix manifest `93a1aa3549b844c399ab1cc2b9bddb1d93ee2070b51c91e80d60875cee4b3ca4`;
- terminal aggregate `bb2806953e979180c408fb55744534be6fa470d4144f210cc50917a9b1006b7d`;
- independent terminal verifier status `PASS_INDEPENDENT_TERMINAL_VERIFICATION_READ_ONLY`;
- exact-query B2 final receipt `c36ec0e31ed913ed4e8077f9a4d9d634d53529ce037ad06af1f48d279b16820e`.

The complete RT matrix and B2 receipt bundles also have a byte-identical canonical local copy under
`results/rt_terminal_stage2_20260811_canonical/`; its copy-only receipt records recursive-diff PASS. The original
run root remains retained because historical receipts contain absolute source paths. Its checkpoint audit is now
complete: 14 unreferenced same-run `last.ckpt` aliases were byte-identical to retained epoch checkpoints and were
replaced by hardlinks without changing any path, SHA, or receipt binding, reclaiming `906,891,264` allocated bytes.
Manifest: `sua_exploration/manifests/rt_terminal_stage2_last_ckpt_hardlink_dedup_20260811.json`, SHA
`e68dd35da75ebde415dcf8af7066f53a217677386d62d6387118dc10d8c949bd`.

## 6. H1 sparse-event boundary and compact consumer

SUA/M2 use one trial direction in
`rate_i(m) ≈ b_i + a_i cos(theta_m) + c_i sin(theta_m)`, while RT supplies one endpoint direction
per go-cue-bounded reach. H1 has only four long calibration trials and each trial contains multiple
heterogeneous 7-DoF events, so it has neither a unique `theta_m` nor one RT-style reach per trial.
Context Full instead uses

```text
x_e = [delta_q_e(7), midpoint_q_e(7), onehot(native_tag_e)]
z_e = P_src Standardize_src(x_e) in R^4
log(1 + rate_i,e) ~= b_i + w_i^T z_e; Context_i = [w_i(4), b_i]
```

The target carrier reads native endpoint pairs and tags, not dense velocity, and is fitted by
closed-form ridge with zero target-session optimizer/backward steps. On the common 8,965-window
fold-0 query, Context Full scores `0.516518`: `+0.019685` over H-S, `+0.016481` over endpoint-only
H-SE5, and `−0.008993` from dense H-C. This is a one-date exploratory result, not the selected H1
paper system; the dense H-C system remains the supported H1 mainline.

| H1 fold-0 system/control | target carrier role | pooled R² |
|---|---|---:|
| H-C | dense carrier | `0.525511` |
| **Context Full** | **sparse endpoint + event context** | **`0.516518`** |
| Context tag shuffle | same-checkpoint tag diagnostic | `0.513960` |
| H-SE5 | endpoint-only sparse ablation | `0.500037` |
| Context endpoint-label shuffle | same-checkpoint content diagnostic | `0.499189` |
| Context row shuffle | same-checkpoint attachment diagnostic | `0.499152` |
| H-S | activity-only SPINT | `0.496833` |
| Context zero | same-checkpoint carrier removal | `0.484059` |
| Zero5 | independently trained zero carrier | `0.471569` |
| Ridge v2r2 | dense per-bin per-session linear readout | `0.258235` |

Context Full exceeds all required pooled content/attachment controls, but Context−H-SE5 is
`−0.004610/+0.077458` across the two recordings. It is therefore a pooled development representative,
not a recording-uniform, cross-date, or organizer-hidden sparse result. The terminal v3 receipt,
structural verifier, and independent batch-29 recomputation SHAs are
`0460cd5f...5695`, `51a14cfa...2bd`, and `98bb86f1...750`.

### 6.1 H-SE5 strict second-date replication

The minimal endpoint-only H-SE5 arm was repeated on outer date `19250108` with an additive dated
implementation that passed exact fold-0 fidelity, source/target isolation and immutable source
snapshot gates. Full and independently trained Zero5 used the same seed, source data, schedule and
fixed epoch-49 checkpoint, then were scored once on 13,107 identical strict post-support windows.

| date-2 system / contrast | pooled R² | per-recording Full−Zero5 |
|---|---:|---|
| H-SE5 Full | `0.495670` | - |
| independently trained Zero5 | `0.518260` | - |
| **Full−Zero5** | **`−0.022590`** | `−0.042554 / +0.001088 / +0.027104` |

Thus the date-1 delta `+0.028469` (2/2 recordings positive) does not replicate on date 2. The
four-trial endpoint-only H1 carrier is therefore not used as a positive paper claim. A structural
verifier passed, and a separate batch-size-29 replay reproduced the pooled delta as `−0.0225895`.
Receipt SHAs: terminal `01f8542b...d0c`, structural verifier
`e909ab36...3b6`, independent replay `9fed4fd9...e31`.

### 6.2 Fold-0 dense-velocity Ridge v2r2 reference

A protocol-corrected two-recording replay provides a descriptive four-trial deployment-boundary
reference on the exact H-SE5 strict post-support query set (8,965 windows). The fixed-normalized-
`lambda=1` per-session Ridge50 maps same-trial causal 50-bin × 176-channel histories to dense 7-DoF
velocity and scores pooled `0.258235` (`0.237329/0.317563` per recording), versus
H-S/H-SE5/Context Full/H-C `0.496833/0.500037/0.516518/0.525511`.

| estimator/package | target-session calibration accounting | pooled R² |
|---|---:|---:|
| Context Full M4 estimator | 41 events; 574 acquired endpoint coordinates; displacement + midpoint derived from the same endpoints; native tags; 164 q4 inputs | `0.516518` |
| H-SE5 M4 endpoint estimator | same 41 events and 574 acquired endpoint coordinates; 287 derived displacement coordinates; 164 q4 inputs | `0.500037` |
| Ridge v2r2 | 6,088 dense 7-DoF velocity rows; 42,616 velocity coordinates | `0.258235` |

These are different algorithmic target representations, not independent observations, effective
sample sizes, human-annotation costs, or matched supervision. The comparison is also not
architecture-matched: Ridge is a direct per-session linear readout, whereas H-S/H-SE5/Context Full/H-C are
source-pretrained decoder systems. It therefore does not establish carrier superiority or explain the
score gap causally. The immutable receipt and from-source
byte-identical verification SHAs are `2c76d3c5...3c28` and `980e0383...3585`; v1/v2 reporting is
superseded by v2r2.

### 6.3 H-U label-free descriptor terminal boundary

The development fold-0 seed-42 H-U arm is terminal at epoch 49 / step 180,500. On the frozen
`665fe535...` query (8,965 windows), four label-free per-unit statistics score pooled `0.4829429873`
(`0.5284200128/0.3507516311` per session), versus matched H-C `0.5255108533` and H-C0
`0.4866156747`: H-U−H-C0 is `−0.0036726874`, H-U−H-C is `−0.0425678660`, and the recovered
carrier increment is `−9.44%`. There were zero target optimizer/backward steps and no formal or organizer
test access (`formal=false`). Thus these four label-free statistics do not recover the H1 carrier increment;
the H-U branch stops with no expansion. This one development cell does not establish universal nonequivalence
or equivalence.
Receipt: `SPINT-main/pilot_artifacts/h1_carrierid_hu/gpu_runs/h32_fold0_hu_v2_envfix/hu/H1_CARRIERID_HU_TERMINAL_EVAL_v9.json`,
SHA `f2f101888125a80dd0e44fb26b048197238fcced1fcf8d924d870cd8eaae9ef4`.

### 6.4 Architecture-preserving SPINT NeuronID width boundary

An activity-only control keeps the H-S/SPINT identity topology, four-trial support, decoder, seed 42,
50-epoch training and fixed epoch-49 read rule unchanged, while replacing every internal identity width
`1024` by `h`. It does not use a carrier. On fold 0, fresh H-S-1024/W224/W32 score
`0.496833/0.432845/0.520634`; the corresponding compact deltas are `-0.063988/+0.023801`.
The frozen `delta R² >= -0.03` routing gate therefore stops W224 and advances only W32; this non-monotonic
pilot must not be summarized as "smaller is always better."

The predeclared W32 confirmation on the four remaining development dates is:

| outer date | reused H-S R² | fresh W32 R² | W32−H-S |
|---|---:|---:|---:|
| `19250108` | `0.426458` | `0.479998` | `+0.053540` |
| `19250113` | `0.256659` | `0.290709` | `+0.034049` |
| `19250115` | `0.441892` | `0.500877` | `+0.058984` |
| `19250119` | `0.294603` | `0.293554` | `-0.001049` |

All four dates pass the non-inferiority margin. The equal-date mean/median deltas are
`+0.036381/+0.043795`; a fixed-seed 200,000-draw outer-date bootstrap gives
`[+0.012598,+0.056262]`. W32 reduces the activity-derived identity path from `5,965,500` to
`60,124` parameters (`99.22x`) and from `2.710B` to `28.813M` dense MACs (`94.05x`). Each W32 model
was trained fresh; the H-S references were reused only after exact source-schedule, support and query binding.
All target evaluations use zero optimizer/backward steps and no formal or organizer data.

This establishes substantial **additional NeuronID encoder capacity redundancy on H1** under the matched
development protocol. It does not compare against constant/no identity, so it neither shows that activity-derived
identity is useless nor bounds identity value on SUA, M2 or RT. Fold-0 terminal receipt SHA:
`b8da8661970ac3ab467b4165bec271bbc5ed67e11c34ee92fdf5369eb39dd1ce`.
Four-date aggregate:
`SPINT-main/pilot_artifacts/h1_spint_width_date_lodo/H1_SPINT_IDENTITY_WIDTH_DATE_LODO_AGGREGATE_v1.json`,
SHA `e65461e89c7d5df2d22a36307248d849534ebc7e9aa4dc09ca520e08aa1ccbb0`.

Five-date development decomposition:

| contrast | equal-date mean | positive dates | date-bootstrap 95% interval |
|---|---:|---:|---:|
| H-C−H-S | **`+0.056287`** | 4/5 | `[+0.005965,+0.097195]` |
| H-C−H-C0 | `+0.032557` | 4/5 | `[−0.004809,+0.079771]` |
| H-C0−H-S | `+0.023730` | 3/5 | `[−0.004455,+0.052217]` |
| H-C−H-LS | `+0.030367` | 4/5 | `[−0.000686,+0.069720]` |

The decomposition exactly satisfies `0.032557+0.023730=0.056287`: carrier content and compact consumer both have
positive mean contributions, but the content-only interval touches zero.

Organizer-held result:

| system | held-out mean ± std | held-in mean ± std | normalized latency |
|---|---:|---:|---:|
| all-source CarrierID `578689` | **`0.274939±0.127206`** | **`0.473125±0.039341`** | **`0.113919`** |
| paper-LR SPINT `578474` | `0.261492±0.148717` | `0.470423±0.048025` | `0.129075` |
| released-LR SPINT `578473` | `0.209917±0.114232` | `0.439027±0.056906` | `0.129293` |

The official endpoint has no per-session scores, so do not claim paired significance or session-uniform superiority.
The compact identity path is about 58k parameters versus 5.97M for H-S, approximately `102.6x` fewer.

The predeclared CI64 width test is also terminal. All 25 fixed-epoch source checkpoints and all five one-shot
held-date evaluations completed on identical within-date query windows. Widening the joint carrier consumer did
not improve the compact CI32 system:

| CI64 contrast | equal-date mean | median | positive dates | disposition |
|---|---:|---:|---:|---|
| FULL−CI32-FULL | **`−0.020130`** | `−0.014332` | 2/5 | width and `+0.03` practical gates fail |
| FULL−C0 | `+0.037980` | `+0.038000` | 4/5 | carrier content remains useful inside CI64 |
| FULL−LS | `+0.026249` | `+0.032680` | 4/5 | correct pairing has a positive average signature |
| FULL−RS | `+0.033704` | `+0.033225` | 5/5 | reported attachment control; not a hard gate |

Thus CI64 does not rescue or enlarge the H1 result: the 32-wide compact consumer is not evidently
capacity-limited, and H64 escalation stops. This negative width result is compatible with the positive content
controls and strengthens the parameter-efficiency interpretation rather than an accuracy-improvement claim.

CI64 aggregate SHA: `534e7d4f2559e03d3cf89a5f7f0b9641172479664ce8095f2d0866ca1e6a7f53`.
Independent read-only verifier status: `PASS_H1_CARRIERID_DATE_LODO_CI_FIVEDATE_TERMINAL_VERIFIED_V2`, SHA
`29d6a5f61b346689f20b8b0274043ea01dc6d96edf34882f21aae1b52c0f7660`.

Official terminal receipt:
`SPINT-main/pilot_artifacts/h1_carrierid_all_source_official_v1/H1_CARRIERID_ALL_SOURCE_EVALAI_TERMINAL_RESULT_RECEIPT_v5.json`,
SHA `b7f76450494f3c0d0ad169de9e89f662c17f435ef2c08bb3d7062908515b488e`.

## 7. M1 and other tested boundaries

| route | result | disposition |
|---|---|---|
| M1 official Original/T4/D4 | `0.648591/0.644766/0.643993` | T4/D4 do not improve Original |
| M1 matched compact EMG-AFC4 Full−Zero4 | `−0.00652463` | authoritative one-cell fold-0 seed-42 development carrier increment; stop |
| M1 matched compact consumer | deltas `+0.095977/−0.033281/+0.047269`; mean `+0.036655` | only 2/3 pass `−0.03`; strict 3/3 non-inferiority closes |
| RT L-D live gain | G-Full−A0 `−0.002068`; G-Full−G-XLS `+0.006606` | fails both `+0.03` gates; stop |
| N4 neural-only carrier on M2 | N4−NS4 `+0.001588`, 3/6 positive | static label-free statistics do not reproduce T4 |
| T4GATE static reliability | T4GATE−T4 `−0.0108±0.0049 SE` | ineffective |
| waveform/SNR/electrode relations | no reliable held-out improvement | do not continue |
| H1 H-PCF8/native-phase precursors | source constructibility gates fail | no GPU |

These close the tested implementations, not every possible self-supervised representation or adaptation method.
For M1, the matched receipt is
`sua_exploration/results/m1_version_b_pilot_aggregate_remote_f0_s42_v3/M1_VERSION_B_F0_S42_AGGREGATE_v1.json`,
SHA `c68f38822fc35414d570f2b932b16491fed763379325ad7efd0529f460e8e035`. The official unmatched
T4−Original `−0.003825` and same-checkpoint whole-identity Full−Zero `+1.8485` are respectively a system
comparison and an identity-reliance ablation, not matched carrier increments.

## 8. Additional completed attribution

The SUA component lattice reports T4/AC4/PH4/MB4/Z4/B4/TS4/LS4
`0.574976/0.562753/0.516961/0.356620/0.326008/0.287273/0.284528/0.265626`.
AC4−T4 is `−0.012222`, inside the `−0.03` tolerance, while T4−Z4 is `+0.248968`. This supports the signed
`[a,c]` functional component; rate-scale alone does not recover the full benefit.

The checkpoint-bound A4 token-content probe provides a separate mechanism readout. Across seeds
42/43/44 and six-session LOSO, AC4 raw/null/advantage is
`0.749669/0.232369/+0.517299`, while Z4 is `0.319513/0.229369/+0.090144`; the paired
AC4-Z4 delta is `+0.430155`, with `18/18` positive seed-session deltas. Thus activity-only tokens
are phase-poor, not phase-free, and AC4 preserves `5.74x` more null-relative cross-session linear
phase signal. This is not a decoder-accuracy result and does not imply nonlinear absence in Z4.
The prose protocol was finalized after the receipts and is not cited as independent pre-registration.
Immutable summary SHA-256:
`6e0ead189ba7deb8aaf42cb5cc2a345e1ecd77f48c5d0fc7af39e878bcaa3e96`.

Paired SUA/pseudo co-training is non-inferior to separate T4 training in the tested matrix:

- shared-T4−separate-T4 `+0.008351/+0.012543` for SUA/pseudo-MUA;
- shared-T4−shared-TS4 `+0.285474/+0.369468`.

These are supporting architecture results, not the main sparse-supervision comparison.

## 9. Paper-safe interpretation

Supported after RT terminal closure:

1. functional carrier content can adapt a frozen streaming decoder without target-session backpropagation;
2. correct content and row attachment matter;
3. useful performance transfers across SUA, pseudo-MUA, and RT; native M2 has positive but scope-limited matched
   development and organizer-held system evidence; H1 contributes a separate dense-carrier compact-consumer
   result, while its four-trial sparse endpoint carrier defines a non-replicating boundary;
4. the evaluated analytic carrier can use substantially fewer target-supervision values than the evaluated dense
   ridge/carrier implementations;
5. the selected carrier-aware identity path is compatible with large parameter compression.

Not supported:

- universal superiority over ridge or SPINT;
- a universal native annotation-cost, compute, latency, energy, or memory advantage;
- a fully sparse-label source-training/scoring pipeline;
- RT sparse superiority over dense Full, equivalence, or non-inferiority;
- recording-uniform, cross-date, or organizer-hidden H1 sparse-carrier evidence;
- positive M1 carrier content;
- label-free calibration.

## 10. 2026-08-13 pilot round

The preceding validation round is closed by the immutable A2 target-subject-shift aggregate
`results/a2_matched_subject_shift_v2/terminal_aggregate.json`, SHA-256
`5b1459df7f65b8dd4cf4ebb9e29b7f82a6def6fc538af71bd822ee26fc7305fc`. Its four means are
within sub-C T4/Z4 `0.574976/0.326008` and external sub-M T4/Z4 `0.341367/-0.143399`; the matched
external-minus-within carrier interaction is `+0.235799`. The six formal sub-C test sessions remain sealed.

Current work is deliberately separated from those terminal results:

| scope | authoritative current state | result status |
|---|---|---|
| A12 descriptive attention audit | `3/24` seed-epoch pairs (seed 42, epochs 5--7), partial aggregate SHA `2bf287307595e5b58e10b3ea00ff082de9873d50421ccd67c9b099764d95eb30`; T4-minus-Z4 normalized entropy `-0.041562`, effective attended units `-2.612026`, and pairwise head cosine `-0.035522`, each negative in 6/6 sessions | descriptive partial only; incomplete, non-causal, no inference, gates nothing |
| B1 carrier x distillation | Stage P terminal under v10 preflight SHA `b20a6dc88297efcd48b0b6081de895befe981be5092953a5705071aa21d14890`; seed-42/43/44 interactions `+0.059153177/+0.004307292/-0.022215337`; mean `+0.0137`; aggregate SHA `0ff38c4b36f64866221d69b456a237ad4fc584bc49b538a7334bea46cd3962c0` | mixed signs and mean below `+0.03`: `STOP_B1_NO_STAGE_F` |
| A1 hidden-space adapter | score SHA `b2b569...`, aggregate SHA `fe8b311...`; primary interaction `+0.0128 R²` | below preregistered `+0.03`: `PILOT_ROUTING_STOP`. Attachment control confirms use but no useful lift |
| C1 / C2 | implementation/design artifacts retained | held; no GPU result and no paper claim |

Workspace maintenance is separate from scientific status: the cold archive at
`/mnt/data/SPINT_cold_archive/2026-08-13/` now contains the initial `8.90 GiB` plus a sealed-batch source-unique
`81.9967 GiB` migration; hard-link deduplication added `74.5878 GiB` of new archive storage. The `49.940 GiB`
`streaming_calibration_exp/logs/train` tree was then archived after path-compatibility smoke tests, and its
original absolute path remains a symlink. Root free space is approximately `208 GB`; pointer-plus-SHA manifests
preserve recovery without changing authoritative artifacts.

## 11. 2026-08-14 CEBRA-inspired non-H1 queue

H1 remains open but is lower priority after the architecture-preserving W32 result: the activity-only identity
path is `99.22x` smaller in parameters and `94.05x` smaller in identity MACs than H-S-1024, with a four-date mean
delta of `+0.036381` and bootstrap interval `[+0.012598,+0.056262]`.  This is an encoder-capacity redundancy
result, not a no-identity result and not a universal carrier-headroom closure.

The first CEBRA-inspired screen was a size-matched continuous-behavior pseudo-session intervention on the
SUA/sub-M route.  Its immutable CPU preflight is
`results/cebra_pseudosession_sua_v1/official_cpu_preflight.json`, SHA-256
`6f1e522053b4e45f2999a852a96d4c3b9b4de3ef318f0ce5a65980fe3dcbd770`.  The immutable seed-42 aggregate is
`results/cebra_pseudosession_sua_v1/stage_p_seed42_aggregate.json`, SHA-256
`16b83e5e4251fe31cbd72d6902fbd8300eaff9217e9c5a9a358020e2c01f7334`.  Relative to the sealed A2 parent,
mix-T4 changed within-sub-C by `+0.009485` and external sub-M by `+0.022609`; the latter missed the frozen
`+0.03` gate.  Stage P therefore stopped without seeds 43/44 or result-guided tuning.  The larger external
carrier interaction (`+0.071772`) does not rescue the failed absolute-accuracy gate.

The forward-only `SetKV-delta` diagnostic is terminal.  Its immutable aggregate is
`results/setkv_delta_forward_v1/terminal_forward_aggregate.json`, SHA-256
`1d6ea6f9fd12623094341b41157ca18c6be26bf134554a939ce53ce7b4009802`.  SetKV-T4 reduced R2 by `-0.738673`
within subject and `-0.638865` on external sub-M, while SetKV-T4 and its row-shuffled sibling were numerically
indistinguishable.  The frozen-forward route therefore stops without joint training.  This diagnostic does
not establish that a jointly trained SetKV consumer is impossible.

The frozen queue behind that terminal gate is:

1. run a source-only value-weighted contribution versus tuning-magnitude mask diagnostic;
2. run a separately contracted session-consistent, rate/T4-matched activity-identity swap v2;
3. continue the fair Track-B CEBRA comparator in parallel through its CPU/source-only gates.

The H1-excluded Track-B v2 comparator has passed its CPU/source-only loader and authority stage for the strict
27-session sub-C source roster in both SUA and pseudo-MUA views; all 27 pseudo-MUA sessions exactly replay the
declared unit-to-electrode pooling.  These development authorities contain no target data, CEBRA fit,
checkpoint, GPU execution, or score.  A single strict-source engineering microbenchmark then measured the
cheapest proposed selector cell (`d=3`, 250 iterations, seed 42): one fit took `5563.348 s`, total wall time was
`5729.817 s` (`95.50 min`), and peak RSS was about `5.83 GiB`; its immutable cost-only receipt SHA-256 is
`1c9f960641d0418da089006245dbe0141769c8c07761b9004f349e9ac160cff2`.  It emitted no R2/winner and opened no
outer target/formal data.  The original 324-fit selector is therefore closed on measured CPU economics
(`>=20.9` serial days even at the cheapest measured-cell cost), and the 12-fit grouped replacement is not
adopted because it changes source exposure and still costs roughly `10.6` CPU days.  Track-B now uses an
externally fixed, non-selected CEBRA geometry: `d=8`, 10,000 iterations, normalized ridge `lambda=0.01`, and
cosine kNN `k=3`.  Before any target access, one separately reviewed source-only `d=8`/250-iteration GPU cost
fit must establish the actual runtime and device-memory budget; it cannot emit a scientific score or alter the
fixed geometry.  `MultiSessionSolver` remains the future accuracy comparator;
`UnifiedSolver` has a fixed concatenated source-unit input width and cannot serve a standalone unseen target,
so it emits no accuracy claim.  No CEBRA accuracy number is recorded here.

The future Track-B accuracy contrast will be trial-prefix matched but deliberately not label-density matched:
CEBRA-Behavior consumes dense bin-level velocity within the M50/M24 prefix, whereas T4 consumes sparse
trial-level supervision.  This choice follows CEBRA's valid continuous-behavior path (RT's native direction
column is degenerate) and favours CEBRA on available calibration information.  Any result must report the two
label counts explicitly rather than calling the comparison equal-information.

The A2 external Z4 score `-0.143399` is not recorded as proof that activity-derived identity is intrinsically
misleading: Z4 retains activity identity and lacks only carrier content.  The identity-swap line is therefore a
new causal test.  Gauge augmentation and all-bin supervision are not queued fallbacks, and a mechanism migrates
to M2 and then RT only after a three-seed absolute external-T4 gain.
